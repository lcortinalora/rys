<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>Registro de empresa</title>
</head>
<body>
    <div class="container">
        <h4>Gestion de Empresa</h4>
        <div class="row">
                  <div class="col-xl-12">
                <form action="{{Route('empresa.index')}}" method="get">
                    <div class="form-row">
                        <div class="col-sm-4 my-1" >
                              <input type="text" class="form-control" name="texto" value="{{$texto}}">
                                                
                        <div class="col-auto my-1">
                        <input type="submit" class="btn btn-primary" value="Buscar">
                        <a href="{{Route('empresa.create')}}" class="btn btn-success">Nuevo</a>
                        </div>
                        </div>
                    </div> 
                </form>
            </div>

            <div class="container">
     
           
  <div class="row">
        <div class="col-xl-12">                     
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <TR>
                            <TH>OPCION</TH>
                            <TH>NOMBREDEEMPRESA</TH>
                            <TH>NIT</TH>
                            <TH>CORREO</TH>
                            <TH>TELEFONO</TH>
                            <TH>MESA</TH>
                        </TR>
                    </thead>
                    <TBody>
                        @if(count($empresas)<=0)
                        <tr>
                            <td colspan="6"> No Hay Resultado</td>
                        </tr>
                        @else
                        @foreach ($empresas as $empresa)
                        <tr>
                                 
                            <td><a href="{{Route('empresa.edit',$empresa->id)}}" class="btn btn-warning btn-sm">Editar</a>
                        
                            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-{{$empresa->id}}">
                             Eliminar
                            </button>        </td>
                            </td>
                            
                            <td>{{$empresa->nombreempresa}}</td>
                            <td>{{$empresa->nit}}</td>
                            <td>{{$empresa->correo}}</td>
                            <td>{{$empresa->telefono}}</td>
                            <td>{{$empresa->mesa}}</td>
                            
                        </TR>
                        @include('empresa.delete')
                        @endforeach
                        @endif
                    </TBody>
                </table>
                {{$empresas->links()}}
                </div>
            </div>
        </div>
    </div>  

</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</html>