<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <title>Registro Empresa</title>
</head>
<body>
    <div class="cotainer">
        <h4>Nueva empresa</h4>
            <div class="row">
                <div class="col-xl-12">
                <form action="{{Route('empresa.store')}}" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="nombreempresa">Nombre de empresa</label>
                        <input type="text" class="form-control" name="nombreempresa" >
                    </div>
                    <div class="form-group">
                        <label for="nit"> NIT</label>
                        <input type="text" class="form-control" name="nit" require maxlength="20">
                    </div>
                    <div class="form-group">
                        <label for="correo">Correo Electronico</label>
                        <input type="text" class="form-control" name="correo" require maxlength="40">
</div>
                    <div class="form-group">
                        <label for="telefono">Telefono</label>
                        <input type="text" class="form-control" name="telefono" require maxlength="40">

                        <div class="form-group"> 
        <label for="mesa" class="control-label">Mesa</label>
        <select class="form-control" id="MESA" name="MESA" >
            <option value="Mesa1">MESA1</option>
            <option value="Mesa2">MESA2</option>
            <option value="Mesa3">MESA3</option>
        </select>                    
    </div>
                        <div class="form-group">
<input type="submit" class="btn btn-primary" value="Guardar">
<input type="reset" class="btn btn-success" value="cancelar">
    <a href="javascript:history.back()">ir al listado</a>
</input:Submit>
</div>

            </form>
            </div>      

    </div>      
 </div>
</body>
</html>