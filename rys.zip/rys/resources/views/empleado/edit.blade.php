<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <title>Modificar Empleado</title>
</head>
<body>
    <form action="{{Route('empleado.update', $empleado->id)}}" method="post">
        @csrf
        @method('put')
        <div class="form-group"> 
            <label for="tipo" class="control-label">cargo</label>
            <select class="form-control" id="tipo" name="tipo" value="{{$empleado->tipoempleado}}">
                <option value="Tecnico">Tecnico</option>
                <option value="Coordinador">Coordinador</option>
                <option value="Gerente">Administrativo</option>
            </select> 
    <div class="form-group"> 
        <label for="nombreempleado" class="control-label">Nombre</label>
        <input type="text" class="form-control"  name="nombreempleado" value="{{$empleado->nombre}}" >
    </div>    

    <div class="form-group"> 
        <label for="apellido" class="control-label">Apellidos</label>
        <input type="text" class="form-control" id="apellido" name="apellido" value="{{$empleado->apellidos}}">
    </div>   
    <div class="form-group"> 
        <label for="fechanacimiento" class="control-label">Fecha de Nacimiento</label>
        <input type="date" class="form-control" id="fechanacimiento" name="fechanacimiento"vale value="{{$empleado->fechadenacimiento}}">
    </div>                 
    <div class="form-group"> 
        <label for="tipodocumento" class="control-label">Tipo de Documento</label>
        <select class="form-control" id="tipodocumento" name="tipodedocumento" vale value="{{$empleado->tipodocumento}}">
            <option value="C.C">Cedula De cuidadania</option>
            <option value="T.E">Tarjeta de Extranjeria</option>
            <option value="C.E">Cedula de Extranjeria</option>
            <option value="Pa">Pasaporte</option>
            <option value="D.I.E">Documento de Indentificacion Extranjero</option>
        </select>                    
    </div>     
            <div class="form-group"> 
        <label for="numerodeindentificacio" class="control-label">Número de identificación</label>
        <input type="text" class="form-control" id="numerodeindentificacio" name="numerodeindentificacio" vale value="{{$empleado->numeroidentificacion}}" >
    </div>    
    <div class="form-group"> 
        <label for="departamento" class="control-label">Departamento</label>
        <input type="text" class="form-control" id="departamento" name="departamento" vale value="{{$empleado->departamento}}" >
    </div> 
    <div class="form-group"> 
        <label for="cuidad" class="control-label">Cuidad</label>
        <input type="text" class="form-control" id="cuidad" name="cuidad" vale value="{{$empleado->cuidad}}" >
    </div> 
    
     
    <div class="form-group"> 
        <label for="numerodecelular" class="control-label">Numero de celular</label>
        <input type="text" class="form-control" id="numerodecelular" name="celular" vale value="{{$empleado->celular}}" >
    </div> 
    <div class="form-group"> 
        <label for="Email" class="control-label">Email</label>
        <input type="text" class="form-control" id="email" name="email" vale value="{{$empleado->email}}" >
    </div> 
    <div class="form-group"> 
        <label for="fechaingreso" class="control-label">Fecha de Ingreso</label>
        <input type="date" class="form-control" id="fechaingreso" name="fechaingreso" vale value="{{$empleado->fechaingreso}}">
    </div> 
    <div class="form-group"> 
        <label for="tipoformacion" class="control-label">Formacion</label>
        <select class="form-control" id="tipoformacion" name="tipoformacion" vale value="{{$empleado->formacion}}" >
            <option value="Tecnico">Tecnico</option>
            <option value="Tecnologo">Tecnologo</option>
            <option value="Profesiona">Profesiona</option>
            <option value="Especialista">Especialista</option>
        </select>                    
    </div>

    <div class="form-group"> 
        <label for="Carrera" class="control-label">Carrera</label>
        <input type="text" class="form-control" id="carrera" name="carrera" vale value="{{$empleado->carrera}}" >
    </div> 
    
    <div class="form-group"> 
        <label for="perfillaboral" class="control-label">Perfil labora</label>
        <select class="form-control" id="perfillaboral" name="perfillaboral"  vale value="{{$empleado->perfillaboral}}">
            <option value="Junior">Junior</option>
            <option value="Senior">Senior</option>
            <option value="Super Senior"> Super Senior</option>
        </select>                    
    </div>
    <div class="form-group"> 
        <label for="idioma" class="control-label">Idioma</label>
        <select class="form-control" id="idioma" name="idioma"vale value="{{$empleado->idioma}}"  >
            <option value="B1">B1</option>
            <option value="B2">B2</option>
            <option value="C1">C1</option>
            <option value="C2">C2</option>
            <option value="Ninguna">Ninguna</option>
        </select>                    
    </div>
    <div class="form-group"> 
        <label for="licencia" class="control-label">Licencia</label>
        <select class="form-control" id="licencia" name="licencia" vale value="{{$empleado->licencia}}" >
            <option value="A1">A1</option>
            <option value="A2">A2</option>
            <option value="B1">B1</option>
            <option value="B2">B2</option>
            <option value="Ninguna">Ninguna</option>
        </select>                    
    </div>
    <div class="form-group"> 
        <label for="cursoaltura" class="control-label">Curso de Altura</label>
        <select class="form-control" id="cursoaltura" name="cursoaltura"  vale value="{{$empleado->cursoaltura}}">
            <option value="SI">SI</option>
            <option value="NO">NO</option>
          </select>                    
    </div>
    <div class="form-group"> 
        <label for="linea" class="control-label">LINEA DE SERVICIO</label>
        <input type="text" class="form-control"  name="linea" vale value="{{$empleado->lineaservicio}}" >
    </div>  
    <div class="form-group">
<input type="submit" class="btn btn-primary" value="Guardar">
<input type="reset" class="btn btn-success" value="Cancelar">
    <a href="javascript:history.back()">ir al listado</a>
</input:Submit>
</div>


</form>
</body>
</div>      

</div>      
</div>
</html>