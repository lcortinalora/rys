<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <title>Registro Empleado</title>
</head>
<body>
    <form action="{{Route('empleado.store')}}" method="post">
        @csrf
        <div class="form-group"> 
            <label for="tipo" class="control-label">Tipo de Empleado</label>
            <select class="form-control" id="tipo" name="tipo">
                <option value="Tecnico">Tecnico</option>
                <option value="Adminisrador">Administrativo</option>
            </select> 
    <div class="form-group"> 
        <label for="nombreempleado" class="control-label">Nombre</label>
        <input type="text" class="form-control"  name="nombreempleado" >
    </div>    

    <div class="form-group"> 
        <label for="apellido" class="control-label">Apellidos</label>
        <input type="text" class="form-control" id="street1_id" name="apellido" >
    </div>   
    <div class="form-group"> 
        <label for="fechanacimiento" class="control-label">Fecha de Nacimiento</label>
        <input type="date" class="form-control" id="fechanacimiento" name="fechanacimiento" >
    </div>                 
    <div class="form-group"> 
        <label for="tipodocumento" class="control-label">Tipo de Documento</label>
        <select class="form-control" id="tipodocumento" name="tipodedocumento">
            <option value="Cedula De cuidadania">Cedula De cuidadania</option>
            <option value="Tarjeta de Extranjeria">Tarjeta de Extranjeria</option>
            <option value="Cedula de Extranjeria">Cedula de Extranjeria</option>
            <option value="Pasaporte">Pasaporte</option>
            <option value="Documento de Indentificacion Extranjero">Documento de Indentificacion Extranjero</option>
        </select>                    
    </div>     
            <div class="form-group"> 
        <label for="numerodeindentificacio" class="control-label">Número de identificación</label>
        <input type="text" class="form-control" id="numerodeindentificacio" name="numerodeindentificacio" >
    </div>    

    <div class="form-group"> 
        <label for="cuidad" class="control-label">Cuidad</label>
        <input type="text" class="form-control" id="cuidad" name="cuidad" >
    </div> 
    
     <div class="form-group"> 
        <label for="departamento" class="control-label">Departamento</label>
        <input type="text" class="form-control" id="departamento" name="cuidad" >
    </div> 
    <div class="form-group"> 
        <label for="numerodecelular" class="control-label">Numero de celular</label>
        <input type="text" class="form-control" id="numerodecelular" name="celular" >
    </div> 
    <div class="form-group"> 
        <label for="Email" class="control-label">Email</label>
        <input type="text" class="form-control" id="email" name="email" >
    </div> 
    <div class="form-group"> 
        <label for="fechaingreso" class="control-label">Fecha de Ingreso</label>
        <input type="date" class="form-control" id="fechaingreso" name="fechaingreso" >
    </div> 
    <div class="form-group"> 
        <label for="tipoformacion" class="control-label">Formacion</label>
        <select class="form-control" id="tipoformacion" name="tipoformacion" >
            <option value="Tecnico">Tecnico</option>
            <option value="Tecnologo">Tecnologo</option>
            <option value="Profesiona">Profesiona</option>
            <option value="Especialista">Especialista</option>
        </select>                    
    </div>

    <div class="form-group"> 
        <label for="Carrera" class="control-label">Carrera</label>
        <input type="text" class="form-control" id="carrera" name="carrera" >
    </div> 
    <div class="form-group"> 
        <label for="perfillaboral" class="control-label">Perfil labora</label>
        <select class="form-control" id="perfillaboral" name="perfillaboral" >
            <option value="Junior">Junior</option>
            <option value="Senior">Senior</option>
            <option value="Super Senior"> Super Senior</option>
        </select>                    
    </div>
    <div class="form-group"> 
        <label for="idioma" class="control-label">Idioma</label>
        <select class="form-control" id="idioma" name="idioma" >
            <option value="B1">B1</option>
            <option value="B2">B2</option>
            <option value="C1">C1</option>
            <option value="C2">C2</option>
            <option value="Ninguna">Ninguna</option>
        </select>                    
    </div>
    <div class="form-group"> 
        <label for="licencia" class="control-label">Licencia</label>
        <select class="form-control" id="licencia" name="licencia" >
            <option value="A1">A1</option>
            <option value="A2">A2</option>
            <option value="B1">B1</option>
            <option value="B2">B2</option>
            <option value="Ninguna">Ninguna</option>
        </select>                    
    </div>
    <div class="form-group"> 
        <label for="cursoaltura" class="control-label">Curso de Altura</label>
        <select class="form-control" id="cursoaltura" name="cursoaltura" >
            <option value="SI">SI</option>
            <option value="NO">NO</option>
          </select>                    
    </div>
    <label for="liniadeservicio" class="control-label">Linia de Servicio</label>
    <div class="form-check">
        
        <input class="form-check-input" type="checkbox" value="OFIMATICA" id="ofimatica" >
        <label class="form-check-label" for="ofimatica">OFIMATICA</label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="SEGURIDAD" id="seguridad" >
        <label class="form-check-label" for="seguridad">  SEGURIDAD      </label>
      </div>
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="REDES" id="redes" >
        <label class="form-check-label" for="redes">  REDES      </label>
      </div>

      <div class="form-check">
      <input class="form-check-input" type="checkbox" value="ELECTRICIDAD" id="ELECTRICIDAD" >
      <label class="form-check-label" for="ELECTRICIDAD">  ELECTRICIDAD     </label>
    </div>
    <div class="form-check">
        <input class="form-check-input" type="checkbox" value="CONSULTORIA" id="ELECTRICIDAD" >
        <label class="form-check-label" for="ELECTRICIDAD">  CONSULTORIA  </label>
      </div>


      <div class="form-group">
<input type="submit" class="btn btn-primary" value="Guardar">
<input type="reset" class="btn btn-success" value="cancelar">
    <a href="javascript:history.back()">ir al listado</a>
</input:Submit>
</div>
</form>
</body>
</html>