<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        @csrf
        <div class="form-group"> 
        <label for="idemplead" class="control-label">id del empleado</label>
        <input type="text" class="form-control" id="apellido" name="ideempleado" value= >
    </div>  

    <div class="form-group"> 
        <label for="fecharetiro" class="control-label">Fecha de Retiro</label>
        <input type="date" class="form-control" id="fecharetiro" name="fecharetiro"  value="">
    </div> 
    <div class="form-group"> 
        <label for="descripcion" class="control-label">Descripcion</label>
        <input type="text" class="form-control" id="apellido" name="descripcion" value= > 
        </div> 
        <div class="form-group"> 
            <label for="tipo" class="control-label">Esatado</label>
            <select class="form-control" id="tipo" name="estado" value=>
                <option value="0">inactvo</option>
                <option value="1">activo</option>
            </select> 
        </div>
        <div class="form-group">
<input type="submit" class="btn btn-primary" value="Guardar">
<input type="reset" class="btn btn-success" value="Cancelar">
    <a href="javascript:history.back()">ir al listado</a>
</input:Submit>
</div>
    </form>
</body>
</html>