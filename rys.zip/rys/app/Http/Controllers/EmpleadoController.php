<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Empleado;
use Illuminate\Support\Facades\DB;

class EmpleadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
      //  
      $texto=trim($request->get('texto'));
      $empleados=DB::table('empleado')
      ->select('id','tipoempleado','nombre','apellidos','fechadenacimiento','tipodocumento','numeroidentificacion','cuidad','departamento','celular','email','fechaingreso',
      'formacion','carrera','cargo','perfillaboral','idioma','licencia','cursodealtura','lineaservicio')
    ->where('nombre','LIKE','%'.$texto.'%')
    ->orWhere('cuidad','LIKE','%'.$texto.'%')
    ->orWhere('numeroidentificacion','LIKE','%'.$texto.'%')
    ->orderBy('nombre','asc')
    ->paginate(10);
       
        
       
        return view('empleado.index',compact('empleados','texto'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('empleado.create');
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $empleado = new Empleado;
        $empleado->tipoempleado=$request->tipo;
        $empleado->nombreempresa=$request->input('nombreempleado');
        $empleado->apellido=$request->input('apellido');
        $empleado->fechadenacimiento=$request->fechanacimiento;
        $empleado->tipodocumento=$request->tipodedocumento;
        $empleado->numeroidentificacion=$request->input('numerodeindentificacio');
        $empleado->cuidad=$request->input('cuidad');
        $empleado->departamento=$request->input('departamento');
        $empleado->celular=$request->input('celular');
        $empleado->email=$request->input('email');
        $empleado->fechaingreso=$request->fechaingreso;
        $empleado->formacion=$request->tipoformacion;
        $empleado->carrera=$request->input('carrera');

        $empleado->perfillaboral=$request->input('perfillaboral');;
        $empleado->idioma=$request->idioma;
        $empleado->licencia=$request->licencia;
        $empleado->cursodealtura=$request->cursodealtura;
        $empleado->lineaservicio=$request->lineasericio;
        $empresa->save();
        return redirect()-> route('empleado.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $empleado=Empleado::findOrFail($id);
        return view("empleado.edit",compact('empleado'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $empresa=Empresa::findOrFail($id);
        $empleado->tipoempleado=$request->tipo;
        $empleado->nombreempresa=$request->input('nombreempleado');
        $empleado->apellido=$request->input('apellido');
        $empleado->fechadenacimiento=$request->fechanacimiento;
        $empleado->tipodocumento=$request->tipodedocumento;
        $empleado->numeroidentificacion=$request->input('numerodeindentificacio');
        $empleado->cuidad=$request->input('cuidad');
        $empleado->departamento=$request->input('departamento');
        $empleado->celular=$request->input('celular');
        $empleado->email=$request->input('email');
        $empleado->fechaingreso=$request->fechaingreso;
        $empleado->formacion=$request->tipoformacion;
        $empleado->carrera=$request->input('carrera');

        $empleado->perfillaboral=$request->input('perfillaboral');;
        $empleado->idioma=$request->idioma;
        $empleado->licencia=$request->licencia;
        $empleado->cursodealtura=$request->cursodealtura;
        $empleado->lineaservicio=$request->lineasericio;
        $empresa->save();
        return redirect()-> route('empleado.index');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $empleado=Empleado::findOrFail($id);
        $empleado->delete();
         return redirect()-> route('empleado.index');
    }
}
