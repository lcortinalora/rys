<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Empresa;
use Illuminate\Support\Facades\DB;

class EmpresaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $texto=trim($request->get('texto'));
        $empresas=DB::table('empresa')
                ->select('id','nombreempresa','nit','correo','telefono','mesa')
                ->where('nombreempresa','LIKE','%'.$texto.'%');
            //    ->orWhere('mesa','LIKE','%'.$texto.'%')
           //     ->orderBy('nombreempresa','asc')
            //    ->paginate(10);

        return view('empresa.index',compact('empresas','texto'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('empresa.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $empresa = new Empresa;
        $empresa->nombreempresa=$request->input('nombreempresa');
        $empresa->nit=$request->input('nit');
        $empresa->correo=$request->input('correo');
        $empresa->telefono=$request->input('telefono');
        $empresa->mesa=$request->MESA;
        $empresa->save();
        return redirect()-> route('empresa.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $empresa=Empresa::findOrFail($id);
    //  return $empresa;
     return view("empresa.edit",compact('empresa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
       $empresa=Empresa::findOrFail($id);
        $empresa->nombreempresa=$request->input('nombreempresa');
         $empresa->nit=$request->input('nit');
         $empresa->correo=$request->input('correo');
         $empresa->telefono=$request->input('telefono');
         $empresa->mesa=$request->MESA;
         $empresa->save();
         return redirect()-> route('empresa.index');
         }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $empresa=Empresa::findOrFail($id);
        $empresa->delete();
         return redirect()-> route('empresa.index');
    }
}
