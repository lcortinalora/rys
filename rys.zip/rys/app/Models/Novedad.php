<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Novedad extends Model
{
    use HasFactory;
    
    protected $table = 'novedades';
    protected $primarykey="id";
    protected $fillable = [
        'idempleado',
        'fecharetiro',
        'descripcion',
        'estado',
    ];
    public $timestamps = false;
    public function Empleado()
    {
        return $this->belongsTo(Empleado::class, 'idempleado');
    }
}
