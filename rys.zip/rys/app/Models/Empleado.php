<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empleado extends Model
{
    protected $table ="empleado";
protected $primarykey="id";
protected $fillable=[
    'tipoempleado','nombre','apellido','fechadenacimiento','tipodocumento',
      'numeroidentificacion','cuidad','departamento','celular','email','fechaingreso',
      'formacion','carrerra','cargo','perillaboral',
    'idioma','licencia','cursodealtura','lineadeservicio'
];

    // use HasFactory;

    public $timestamps=false;

    public function Novedad()
    {
        return $this->hasOne(Novedad::class, 'idempleado');
    }
}
