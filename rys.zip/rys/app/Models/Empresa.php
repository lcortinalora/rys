<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empresa extends Model
{
protected $table ="empresa";
protected $primarykey="id";
protected $fillable=[
     'nombreempresa','nit','correo','telefono','mesa'
];

    // use HasFactory;

    public $timestamps=false;
}
