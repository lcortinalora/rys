<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    
    <title>Empleado</title>
</head>
<body>
<div class="row">
<h4>Gestion de Empleado</h4>
                  <div class="col-xl-12">
                 <form action="<?php echo e(Route('empleado.index')); ?>" " method="get">
                    <div class="form-row">
                        <div class="col-sm-4 my-1" >
                              <input type="text" class="form-control" name="texto" value="<?php echo e($texto); ?>">
                                                
                         </div>
                         <div class="col-auto my-1">
                        <input type="submit" class="btn btn-primary" value="Buscar">
                        <a href="<?php echo e(Route('empleado.create')); ?>" class="btn btn-success">Nuevo</a>
                        </div>
                    </div> 
                </form>
 </div>



<div class="container">
  <div class="row">
        <div class="col-xl-12">                     
            <div class="table-responsive">
                <table class="table table-striperd">
                <thead>
                        <TR>
                            <TH>Novedades</TH>
                            <TH>OPCION</TH>
                             <TH>NOMBRE</TH>
                            <TH>APELLIDO</TH>
                            <TH>TIPO DE DOCUMENTO</TH>
                            <TH>NUMERO DE IDENTIFICACION</TH>
                            <TH>DEPARTAMENTO</TH>
                            <TH>CUIDAD</TH>
                             <TH>TELEFONO</TH>
                            <TH>EMAIL</TH>
                            <TH>FORMACION</TH>
                            <TH>CARRERA</TH>
                            <TH>PERFIL LABORAL</TH>
                            <TH>IDIOMA</TH>
                            <TH>CURSO DE ALTURA</TH>
                            <TH>LINIA DE SERVICIO</TH>
                        </TR>

                    </thead>
                    
                    <TBody>
                    <?php if(count($empleados)<=0): ?>
                        <tr>
                            <td colspan="16"> NO HAY RESULTADO</td>
                        </tr>
                    <?php else: ?>
                    <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><a href="<?php echo e(Route('empleado.show',$empleado->id)); ?>" class="btn btn-warning btn-sm">Novedades</a>
  
                    <td><a href="<?php echo e(Route('empleado.edit',$empleado->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                        
                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($empleado->id); ?>">
                         Eliminar
                        </button>        </td>
                        </td>

                        </td>
                           <td><?php echo e($empleado->nombre); ?></td>
                            <td><?php echo e($empleado->apellidos); ?></td>
                            <td><?php echo e($empleado->tipodocumento); ?></td>
                            <td><?php echo e($empleado->numeroidentificacion); ?></td>
                            <td><?php echo e($empleado->departamento); ?></td>
                            <td><?php echo e($empleado->cuidad); ?></td>
                            <td><?php echo e($empleado->celular); ?></td>
                            <td><?php echo e($empleado->email); ?></td>
                            <td><?php echo e($empleado->formacion); ?></td>
                            <td><?php echo e($empleado->carrera); ?></td>
                            <td><?php echo e($empleado->perfillaboral); ?></td>
                            <td><?php echo e($empleado->idioma); ?></td>
                            <td><?php echo e($empleado->licencia); ?></td>
                            <td><?php echo e($empleado->lineaservicio); ?></td>

                    </tr>
                    <?php echo $__env->make('empleado.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    <T/Body>
                            </table>
             <?php echo e($empleados->links()); ?>

            </div>
        </div>
        </div>
    </div>

</body>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>

</html><?php /**PATH C:\xampp\htdocs\rys\resources\views/empleado/index.blade.php ENDPATH**/ ?>