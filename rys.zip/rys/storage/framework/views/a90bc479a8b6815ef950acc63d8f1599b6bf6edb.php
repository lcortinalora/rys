<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-F3w7mX95PdgyTmZZMECAngseQB83DfGTowi0iMjiWaeVhAn4FJkqJByhZMI3AhiU" crossorigin="anonymous">
    <title>Registro de empresa</title>
</head>
<body>
    <div class="container">
        <h4>Gestion de Empresa</h4>
        <div class="row">
                  <div class="col-xl-12">
                <form action="<?php echo e(Route('empresa.index')); ?>" method="get">
                    <div class="form-row">
                        <div class="col-sm-4 my-1" >
                              <input type="text" class="form-control" name="texto" value="<?php echo e($texto); ?>">
                           
                        
                        <div class="col-auto my-1">
                        <input type="submit" class="btn btn-primary" value="Buscar">
                        <a href="<?php echo e(Route('empresa.create')); ?>" class="btn btn-success">Nuevo</a>
                        </div>
                        </div>
                    </div> 
                </form>
            </div>

         
            <div class="col-lx-12">
                <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <TR>
                            <TH>OPCION</TH>
                            
                            <TH>NOMBREDEEMPRESA</TH>
                            <TH>NIT</TH>
                            <TH>CORREO</TH>
                            <TH>TELEFONO</TH>
                            <TH>MESA</TH>
                        </TR>
                    </thead>
                    <TBody>
                        <?php if(count($empresas)<=0): ?>
                        <tr>
                            <td colspan="6"> No Hay Resultado</td>

                        </tr>
                        <?php else: ?>
                        <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empresa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <TR>
                                 
                            <td><a href="<?php echo e(Route('empresa.edit',$empresa->id)); ?>" class="btn btn-warning btn-sm">Editar</a>
                        
                            <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modal-delete-<?php echo e($empresa->id); ?>">
                             Eliminar
                            </button>
                        </td>



                            </td>
                            
                            <td><?php echo e($empresa->nombreempresa); ?></td>
                            <td><?php echo e($empresa->nit); ?></td>
                            <td><?php echo e($empresa->correo); ?></td>
                            <td><?php echo e($empresa->telefono); ?></td>
                            <td><?php echo e($empresa->mesa); ?></td>
                            
                        </TR>
                        <?php echo $__env->make('empresa.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </TBody>
                </table>
                <?php echo e($empresas->links()); ?>

                </div>
            </div>
        </div>
    </div>  

</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js" integrity="sha384-W8fXfP3gkOKtndU4JGtKDvXbO53Wy8SZCQHczT5FMiiqmQfUpWbYdTil/SxwZgAN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.min.js" integrity="sha384-skAcpIdS7UcVUC05LJ9Dxay8AXcDYfBJqt1CJ85S/CFujBsIzCIv+l9liuYLaMQ/" crossorigin="anonymous"></script>
</html><?php /**PATH C:\xampp\htdocs\rys\resources\views/empresa/index.blade.php ENDPATH**/ ?>