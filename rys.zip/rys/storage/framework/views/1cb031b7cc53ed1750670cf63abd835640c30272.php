<!-- Modal -->
<div class="modal fade" id="modal-delete-<?php echo e($empleado->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <form action="<?php echo e(route('empleado.destroy',$empleado->id)); ?>" method="post">
     <?php echo csrf_field(); ?>
    <?php echo method_field('delete'); ?>
      

    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminacion De Registro</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Deseas Eliminar el Registro <?php echo e($empleado->nombre); ?>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
         <input type="submit" class="btn btn-danger btn-sm" value="eliminar">
      </div>
    </div>
    </form> 
  </div>
</div><?php /**PATH C:\xampp\htdocs\rys\resources\views/empleado/delete.blade.php ENDPATH**/ ?>